// call this function when "orange-kid" is clicked!
function moveGif() {
  document.getElementById("goku").classList.add("flyforward");
  document.getElementById("OrangeBox").classList.add("translucent");
}

// call this function when "blue-man" is clicked!
function transform() {
  document.getElementById("blue-man").src = "images/vegeta_ultrainstinct.png";
  document.getElementById("BlueBox").classList.add("translucent");
}
