var a = document.getElementById("one");
var b = document.getElementById("two");
var c = document.getElementById("three");
var d = document.getElementById("four");
var e = document.getElementById("five");
var f = document.getElementById("six");
var fp = document.getElementById("fingerprint");
var r1 = document.getElementById("r1");
var r2 = document.getElementById("r2");
var r3 = document.getElementById("r3");
var r4 = document.getElementById("r4");
var r5 = document.getElementById("r5");
var r6 = document.getElementById("r6");

function showPuzzle() {
  r1.classList.remove("none");
  r2.classList.remove("none");
  r3.classList.remove("none");
  r4.classList.remove("none");
  r5.classList.remove("none");
  r6.classList.remove("none");
}
var slot1Array = [
  "images/row-3-column-1.png",
  "images/row-4-column-1.png",
  "images/row-5-column-1.png",
  "images/row-6-column-1.png",
  "images/row-1-column-1.png",
  "images/row-2-column-1.png"
];
var l = 0;

function slot1() {
  a.src = slot1Array[l];
  l = l + 1;
  if (l > 5) {
    l = 0;
  }
}

var slot2Array = [
  "images/row-1-column-1.png",
  "images/row-2-column-1.png",
  "images/row-3-column-1.png",
  "images/row-4-column-1.png",
  "images/row-5-column-1.png",
  "images/row-6-column-1.png"
];
var m = 0;

function slot2() {
  b.src = slot2Array[m];
  m = m + 1;
  if (m > 5) {
    m = 0;
  }
}

var slot3Array = [
  "images/row-5-column-1.png",
  "images/row-6-column-1.png",
  "images/row-1-column-1.png",
  "images/row-2-column-1.png",
  "images/row-3-column-1.png",
  "images/row-4-column-1.png"
];
var r = 0;

function slot3() {
  c.src = slot3Array[r];
  r = r + 1;
  if (r > 5) {
    r = 0;
  }
}
var slot4Array = [
  "images/row-4-column-1.png",
  "images/row-5-column-1.png",
  "images/row-6-column-1.png",
  "images/row-1-column-1.png",
  "images/row-2-column-1.png",
  "images/row-3-column-1.png"
];
var u = 0;

function slot4() {
  d.src = slot4Array[u];
  u = u + 1;
  if (u > 5) {
    u = 0;
  }
}

var slot5Array = [
  "images/row-6-column-1.png",
  "images/row-1-column-1.png",
  "images/row-2-column-1.png",
  "images/row-3-column-1.png",
  "images/row-4-column-1.png",
  "images/row-5-column-1.png"
];
var z = 0;

function slot5() {
  e.src = slot5Array[z];
  z = z + 1;
  if (z > 5) {
    z = 0;
  }
}

var slot6Array = [
  "images/row-2-column-1.png",
  "images/row-3-column-1.png",
  "images/row-4-column-1.png",
  "images/row-5-column-1.png",
  "images/row-6-column-1.png",
  "images/row-1-column-1.png"
];
var v = 0;

function slot6() {
  f.src = slot6Array[v];
  v = v + 1;
  if (v > 5) {
    v = 0;
  }
}

function startTimer(duration, display) {
  var timer = duration,
    minutes,
    seconds;
  setInterval(function () {
    minutes = parseInt(timer / 60, 10);
    seconds = parseInt(timer % 60, 10);

    minutes = minutes < 10 ? "0" + minutes : minutes;
    seconds = seconds < 10 ? "0" + seconds : seconds;

    display.textContent = minutes + ":" + seconds;

    if (--timer < 0) {
      timer = duration;
    }
  }, 1000);
}

window.onload = function () {
  var twoMinutes = 60 * 2,
    display = document.querySelector("#time");
  startTimer(twoMinutes, display);
};

var i;
function storeStuff(el) {
  console.log(el);
  i = el.src;
  console.log(el.id);
}
function setStuff() {}
