// call this function when "orange-kid" is clicked!
function moveGif() {
  document.getElementById("goku").classList.add("flyforward");
  document.getElementById("OrangeBox").classList.add("translucent");
  document.getElementById("BlueBox").classList.remove("translucent");
  document.getElementById("blue-man").src.remove =
    "images/vegeta_ultrainstinct.png";
}

// call this function when "blue-man" is clicked!
function transform() {
  document.getElementById("blue-man").src = "images/vegeta_ultrainstinct.png";
  document.getElementById("BlueBox").classList.add("translucent");
  document.getElementById("OrangeBox").classList.remove("translucent");
}
