var a = document.getElementById("one");
var b = document.getElementById("two");
var c = document.getElementById("three");
var d = document.getElementById("four");
var e = document.getElementById("five");
var f = document.getElementById("six");
var fp = document.getElementById("fingerprint");
var r1 = document.getElementById("r1");
var r2 = document.getElementById("r2");
var r3 = document.getElementById("r3");
var r4 = document.getElementById("r4");
var r5 = document.getElementById("r5");
var r6 = document.getElementById("r6");
var buttonclick = document.getElementById("buttonclick");
var hint = document.getElementById("hint");
var nextbutton = document.getElementById("nextbutton");

function ShowPuzzle() {
  buttonclick.play();
  r1.classList.remove("none");
  r2.classList.remove("none");
  r3.classList.remove("none");
  r4.classList.remove("none");
  r5.classList.remove("none");
  r6.classList.remove("none");
  hint.classList.remove("none");
  document.getElementById("fingerprint").removeAttribute("onclick");
  document.getElementById("fingerprint").classList.add("opaque");
  document.getElementById("fingerprint").classList.add("disabled");
}

function random(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function slot1() {
  buttonclick.play();
  l = random(1, 6);
  if (l == 1) {
    a.src = "images/row-1-column-1.png";
  } else if (l == 2) {
    a.src = "images/row-2-column-1.png";
  } else if (l == 3) {
    a.src = "images/row-3-column-1.png";
  } else if (l == 4) {
    a.src = "images/row-4-column-1.png";
  } else if (l == 5) {
    a.src = "images/row-5-column-1.png";
  } else if (l == 6) {
    a.src = "images/row-6-column-1.png";
  }
}

function slot2() {
  buttonclick.play();
  l = random(1, 6);
  if (l == 1) {
    b.src = "images/row-1-column-1.png";
  } else if (l == 2) {
    b.src = "images/row-2-column-1.png";
  } else if (l == 3) {
    b.src = "images/row-3-column-1.png";
  } else if (l == 4) {
    b.src = "images/row-4-column-1.png";
  } else if (l == 5) {
    b.src = "images/row-5-column-1.png";
  } else if (l == 6) {
    b.src = "images/row-6-column-1.png";
  }
}

function slot3() {
  buttonclick.play();
  l = random(1, 6);
  if (l == 1) {
    c.src = "images/row-1-column-1.png";
  } else if (l == 2) {
    c.src = "images/row-2-column-1.png";
  } else if (l == 3) {
    c.src = "images/row-3-column-1.png";
  } else if (l == 4) {
    c.src = "images/row-4-column-1.png";
  } else if (l == 5) {
    c.src = "images/row-5-column-1.png";
  } else if (l == 6) {
    c.src = "images/row-6-column-1.png";
  }
}

function slot4() {
  buttonclick.play();
  l = random(1, 6);
  if (l == 1) {
    d.src = "images/row-1-column-1.png";
  } else if (l == 2) {
    d.src = "images/row-2-column-1.png";
  } else if (l == 3) {
    d.src = "images/row-3-column-1.png";
  } else if (l == 4) {
    d.src = "images/row-4-column-1.png";
  } else if (l == 5) {
    d.src = "images/row-5-column-1.png";
  } else if (l == 6) {
    d.src = "images/row-6-column-1.png";
  }
}

function slot5() {
  buttonclick.play();
  l = random(1, 6);
  if (l == 1) {
    e.src = "images/row-1-column-1.png";
  } else if (l == 2) {
    e.src = "images/row-2-column-1.png";
  } else if (l == 3) {
    e.src = "images/row-3-column-1.png";
  } else if (l == 4) {
    e.src = "images/row-4-column-1.png";
  } else if (l == 5) {
    e.src = "images/row-5-column-1.png";
  } else if (l == 6) {
    e.src = "images/row-6-column-1.png";
  }
}

function slot6() {
  buttonclick.play();
  l = random(1, 6);
  if (l == 1) {
    f.src = "images/row-1-column-1.png";
  } else if (l == 2) {
    f.src = "images/row-2-column-1.png";
  } else if (l == 3) {
    f.src = "images/row-3-column-1.png";
  } else if (l == 4) {
    f.src = "images/row-4-column-1.png";
  } else if (l == 5) {
    f.src = "images/row-5-column-1.png";
  } else if (l == 6) {
    f.src = "images/row-6-column-1.png";
  }
}
var interval;
function startTimer(duration, display) {
  var timer = duration,
    minutes,
    seconds;
  interval = setInterval(function () {
    minutes = parseInt(timer / 60, 10);
    seconds = parseInt(timer % 60, 10);

    minutes = minutes < 10 ? "0" + minutes : minutes;
    seconds = seconds < 10 ? "0" + seconds : seconds;

    display.textContent = minutes + ":" + seconds;

    if (--timer < 0) {
      window.location.reload();
      timer = duration;
    }
  }, 1000);
}

window.onload = function () {
  var twoMinutes = 60 * 2,
    display = document.querySelector("#time");
  startTimer(twoMinutes, display);
};

function puzzleComplete() {
  if (
    a.src.match("images/row-1-column-1.png") &&
    b.src.match("images/row-2-column-1.png") &&
    c.src.match("images/row-3-column-1.png") &&
    d.src.match("images/row-4-column-1.png") &&
    e.src.match("images/row-5-column-1.png") &&
    f.src.match("images/row-6-column-1.png")
  ) {
    stopTimer();
    a.classList.add("disabled");
    b.classList.add("disabled");
    c.classList.add("disabled");
    d.classList.add("disabled");
    e.classList.add("disabled");
    f.classList.add("disabled");
    a.classList.add("opaque");
    b.classList.add("opaque");
    c.classList.add("opaque");
    d.classList.add("opaque");
    e.classList.add("opaque");
    f.classList.add("opaque");
    a.removeAttribute("onclick");
    b.removeAttribute("onclick");
    c.removeAttribute("onclick");
    d.removeAttribute("onclick");
    e.removeAttribute("onclick");
    f.removeAttribute("onclick");
    hint.classList.add("opaque");
    hint.classList.remove("black");
    document.getElementById("row2").classList.add("green");
    r1.classList.remove("black");
    r2.classList.remove("black");
    r3.classList.remove("black");
    r4.classList.remove("black");
    r5.classList.remove("black");
    r6.classList.remove("black");
    nextbutton.classList.remove("invis");
    /*r1.classList.add("green");
    r2.classList.add("green");
    r3.classList.add("green");
    r4.classList.add("green");
    r5.classList.add("green");
    r6.classList.add("green");*/
  }
}
function nextPage() {
  window.location.href = "https://jx50zp.csb.app/";
}

function stopTimer() {
  console.log("complete!");
  window.clearInterval(interval);
}
