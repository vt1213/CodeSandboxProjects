function ActivateAll() {
  document.getElementById("bear").src = "images/voliult.gif";
  document.getElementById("mord").src = "images/mordult.gif";
  document.getElementById("time").src = "images/rewind.gif";
  document.getElementById("dog").src = "images/dogkill.gif";
  document.getElementById("darkin").src = "images/troxkills.gif";
}

function BearUlt() {
  document.getElementById("bear").src = "images/voliult.gif";
}
function Realm() {
  document.getElementById("mord").src = "images/mordult.gif";
}
function Rewind() {
  document.getElementById("time").src = "images/rewind.gif";
}
function SingedDies() {
  document.getElementById("dog").src = "images/dogkill.gif";
}
function ZerathDies() {
  document.getElementById("darkin").src = "images/troxkills.gif";
}

function ResetBear() {
  document.getElementById("bear").src = "images/VOLIBEARt.png";
}
function ResetMord() {
  document.getElementById("mord").src = "images/morde.png";
}
function ResetDog() {
  document.getElementById("dog").src = "images/dog.png";
}
function ResetAatrox() {
  document.getElementById("darkin").src = "images/trox.png";
}
function ResetEkko() {
  document.getElementById("time").src = "images/ekko.png";
}
// JavaScript is capitalized using "camel case": https://en.wikipedia.org/wiki/Camel_case
// Check out the power of the classList property: https://www.w3schools.com/jsref/prop_element_classlist.asp

// These W3Schools links show efficient ways of completing some of the challenges!
// https://www.w3schools.com/jsref/prop_style_height.asp
// https://www.w3schools.com/jsref/prop_html_innerhtml.asp
// https://www.w3schools.com/js/tryit.asp?filename=tryjs_visibility
